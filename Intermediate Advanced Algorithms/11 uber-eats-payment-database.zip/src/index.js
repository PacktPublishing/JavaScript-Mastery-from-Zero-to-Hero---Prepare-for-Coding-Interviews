// Course Notes:
document.getElementById("lesson").innerHTML = `
Object Constructors in JavaScript 

Sometimes we need a "blueprint" for creating many objects of the same "type".

The way to create an "object type", is to use an object constructor function.

The this keyword in JavaScript is the object that 'owns' the code. 

Example 1: Object Constructor Function

`;

// Code Examples:

// Example 1: Object Constructor Function

function Cyborg(_first, _last, _age, _eyes, _invisibilityMode) {
  this.firstName = _first;
  this.lastName = _last;
  this.age = _age;
  this.eyes = _eyes;
  this.invisibilityMode = _invisibilityMode;
}

console.log(
  "Example 1:",
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Solo", 300, "auburn", true),
  new Cyborg("Hans", "Quatro", 299.999999999, "black", true)
);

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise: Uber Eats Payment Database

You are building a CMS frontend payment database for Uber Eats. 
The higherups ask you to build an object constructor to generate user object data
called userGenerator.

1. The blueprint of the object should have keys for the full name (first and last),
location, and billing.  The data should include an entire name 
(first name and last name), address, and billing information.

2. Create four new user objects with userGenerator 
with the following string information passed as arguments 
(entireName, address, billing):

user1: Lisa Simpson, Carribeans, Mastercard
user2: Michael Jordan, Chicago, Visa
user3: Bunny Foofoo, Canada, null
user4: The Dude, LA, Ethereum 

3. Store the user objects of only the users that have filled out valid billing information
(vaild billing methods can only include Visa or Ethereum) in an array payingUsersDatabase.

4. Console log a message displaying how many total users there are being
generated, how many users with valid billing there are, 
and all the data of only the users with valid billing.

5. Share your solution on the discord and break a leg! `;

// Exercise Solution:

let totalNewUsers = [];
let payingUserDatabase = [];
let totalValidPaymentUsers = 0;

var UserGenerator = function (_entireName, _location, _billing) {
  this.fullName = _entireName;
  this.location = _location;
  this.billing = _billing;
};

function createNewUser(_name, _location, _billing) {
  totalNewUsers.push(new UserGenerator(_name, _location, _billing));
  addNewPaymentUsers();
}

createNewUser("Lisa Simpson", "Carribeans", "Mastercard");
createNewUser("The Dude", "LA", "Ethereum");
createNewUser("Michael Jordan", "Chicago", "Visa");
createNewUser("Bunny Foofoo", "Canada", null);

function addNewPaymentUsers() {
  let newObjData = {};
  for (let i = 0; i < totalNewUsers.length; i++) {
    newObjData.fullName = totalNewUsers[i].fullName;
    newObjData.location = totalNewUsers[i].location;
    newObjData.billing = totalNewUsers[i].billing;
  }
  let billingExists = newObjData.billing;
  if (billingExists) {
    if (billingExists === "Ethereum" || billingExists === "Visa") {
      totalValidPaymentUsers++;
      return payingUserDatabase.push(newObjData);
    }
  }
}

console.log(
  "Exercise Solution",
  `Total new users are
${totalNewUsers.length} of which ${totalValidPaymentUsers}
users have valid payment methods.`,
  payingUserDatabase
);

//name, address, billing information
