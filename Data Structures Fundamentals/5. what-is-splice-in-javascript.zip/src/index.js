// Course Notes:
document.getElementById("lesson").innerHTML = `
Remove Items in Arrays with the Splice Method 

Now that've covered how to remove elements in the first
position and the last position in arrays, let's now
look at a customizable way to remove items anywhere
we indicate inside an array - The Splice Method.

Splice can remove any number of items from an array
consecutively given a starting input which we define. 

Splice takes three arguments: 
1. The first argument is for selecting the starting position
of where we want to remove elements 
2. The second argument denotes how many items will be 
consecutively deleted from the starting position. 

Ex 1 Splice Method Below

Splice can also be used to create a new copy of the
array with the removed items. 

Ex 2 Splice Method to Return a new array

`;

// Code Examples:
// Example 1: Splice Method

let colorsArray = ["blue", "green", "brown", "black"];
console.log("Example 1:", colorsArray);
colorsArray.splice(2, 2);

// Example 2 Splice Method to Return a new array

let array = [1, 2, 3, 4];
let newArray = array.splice(2, 2);
console.log("Example 2:", newArray);

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise - Use Splice to decode the puzzle 

OBJ: You work for the CIA and your job is to decode an unusual communicaiton of strings
(a sequence of strings) with a hidden message using the splice method. 

The final sentence  should only contain the following sequence of indexed 
values of the INITIAL strings in the given array: 2,3,5,6,7

1. Initialize an array called jumbled with the following strings consecutively:
'unlock', 'hidden', 'the', 'cat', 'messages', 'jumped', 'over', 'the moon'  

2. You can only use the splice method to selectively decode and return the final message
logged in the console. 

BONUS Return the deleted items to a new variable called CIAConfidential and share both 
confidential decoded logs in the discord in the #datastructures channel. 

Good luck saving the world! 

`;

// Exercise Solution:
const jumbled = [
  "unlock",
  "hidden",
  "the",
  "cat",
  "messages",
  "jumped",
  "over",
  "the moon"
];

// KEEPERS: 2 = the, 3 = cat, 5 = jumped, 6 = over, 7 = the moon

// REMOVALS: 0 = unlock, 1 = hidden, 4 = messages

let newJumbled = [...jumbled];

let CIAConfidential = newJumbled.splice(0, 5);
CIAConfidential.splice(2,2)
console.log("CIAConfidential", CIAConfidential);

jumbled.splice(0, 2);
jumbled.splice(2, 1);

console.log("Exercise Solution:", jumbled);
