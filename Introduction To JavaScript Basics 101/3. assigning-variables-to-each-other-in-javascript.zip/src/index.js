// Course Notes:
document.getElementById("lesson").innerHTML = `

  In JavaScript you can assign one variable to another using
  the assignment operator: = 

  Recall declaring and assigning variables:
  var hello = 'Welcome!'



`;

// Code Examples:

/* Lets say we are building a game and we want to assign
some characters to say hello and others not to
*/

// this works for 3 characters
// var teacher = 'Welcome!'
// var student = 'Welcome!'
// var friend  = 'Welcome!'
// var uncle

// imagine we have 10,000 characters

var hello = "Welcome!";

var teacher = hello;
var student = hello;
var friend = hello;
var uncle;

console.log("Example", teacher, student, friend, uncle);

// Exercise
document.getElementById("exercise").innerHTML = `
Build Your First Basic Calculator in JavaScript
1. Declare two variables as numbers and initialize them.
One variable named five should be initialized to the number 5
Another variable named four should be initialized to the number 4

2. Declare another variable called calculator and using the assignment operator
assign to the calculator variable the variable five plus the variable four 
so that the results yield 9.

3. Display your result in the Console

4. Bonus! Create your own calculator and share the code on discord! 
`;

// Exercise Solution:

var five = 5;
var four = 4;

var calculator = five + four;

console.log("Solution:", calculator);
