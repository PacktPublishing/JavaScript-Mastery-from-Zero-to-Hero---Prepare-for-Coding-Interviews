// Course Notes:
document.getElementById("lesson").innerHTML = `
Modifying arrays by adding new items with the 
push and unshift method. 

Arrays do not have a fixed size and they can be dynamically
modified as to the items that they store. 

Elements can be added and removed over time and therefore 
array data is mutable. 

Let's take a look at two examples which can add new elements
into an array by modifying the array at its beginning point
and its end point. 

** push adds elements to the end of an array while unshift add
elements to the end of an array. Both methods can pass one or
more arguments depending on how many items you'd like to pass into
an array. 

Ex 1 Below
`;

// Code Examples:
// Ex 1 (push and unshift methods)

let kitchenItems = ["fork", "knife", "plates"];
console.log("Example 1:", kitchenItems);
kitchenItems.unshift("cabinet");
kitchenItems.pop();
kitchenItems.push("plates");

// Exercise
document.getElementById("exercise").innerHTML = `

1. Write a function called dragonBallZ which takes an array parameter
and returns the array.
2. log the results of the dragonBallZ function passing into the argument the string 'Bulma'
into the array. 
3. Back in the function dragonBallZ, modify the array with the push and unshift methods.
Add to the beginning of the array the strings San Goku and Piccalo, and add at the end
of the array the string Vegeta. 
4. Write kamehameha in the DPO discord to celebrate your victory after successfully completing
the task. ;)  

`;

// Exercise Solution:

function dragonBallZ(array) {
  array.unshift("San Goku", "Piccalo");
  array.push("Vegeta");
  return array;
}

console.log("Exercise Solution", dragonBallZ(["Bulma"]));
