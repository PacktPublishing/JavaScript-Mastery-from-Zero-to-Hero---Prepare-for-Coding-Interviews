// Course Notes:
document.getElementById("lesson").innerHTML = `

Loops can execute a block of code a number of times.

JavaScript Loops
Loops are helpful, in order to repeat the same code
over and over again, and provide different values each time

Often this is the case when working with arrays:


`;

// Code Examples:

let users = ["Ray", "Susan", "Fake Account", "Batman"];

// for loop example
// 3 expressions in the
// for loop
// 1 initialize index
// 2 second expression dTe hnotes
// how long or where do we
// wish to loop until
// 3 we can decide what happens to i
// for the next iteration
// let i = 0;
// for (let i = 0; i < users.length; i++)
for (let i = users.length - 1; i >= 0; i--) {
  console.log(users[i]);
  console.log(i + 1);
}

console.log("example 1", users.length);

// Exercise
document.getElementById("exercise").innerHTML = `

Create an algorthim using a for loop 
that can add the sum of natural numbers up to 50
(You should use ES6 correctly for variable storage)

So positive whole numbers example: 1, 2, 3, etc
The sum of natural numbers of 3 ex: 1 + 2 + 3 = 6 
`;

let sum = 0;
const n = 50;

for (let i = n; i >= 1; i--) {
  // sum = sum + i;
  sum += i;
}
console.log("solution", sum);
