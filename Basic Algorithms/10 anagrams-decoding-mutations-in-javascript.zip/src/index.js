// Course Notes:
document.getElementById("lesson").innerHTML = `
Anagrams - Decoding Mutations in JavaScript

Anagram: cinema and iceman
rearrange iceman to cinema: iceman - cinema

What if we had an array of two strings that held the exact 
same values except in a different order? How could we go about verifying whether
they actually contained the same values or not programmatically?

IE: 1.'hello', 'olleh'
Expected: true
    2. 'word', 'friend'
Expected: false
`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise - Write A Program to Solve Anagram Puzzles 

Someone stops you on the street and says, 'hey you! Can you please help me!'

Given the following Comparison List: 

1. 'dynamite' – 'mayitend'	
2. 'Statue of Liberty' – 'Sticky Bird free'
3. 'eleven plus two' – 'twelve plus one'	
4. 'dragon king' - 'going Darn'
5. 'the Morse Code' – 'here come dots'
6. 'the nudist colony' – 'no untidy clothes'

1. Create 6 arrays which contain two strings each. The first string in the array 
should be the first anagram string and the second string should be the second anagram string we are comparing.
IE: array1 = ['dynamite', 'mayitend'] 

2. Write a function which can determine whether the following phrase comparisons
are anagrams or not. If they are anagrams the function should return true
otherwise the function should return false!

*Be mindful to not add or change any spaces between phrases as we are not looking
at regex for this example and copy the strings in the description exactly as is.

Please share your solutions in the discord along with only the anagrams that are 
actually anagrams. 


1. 'dynamite' – 'mayitend'	
2. 'Statue of Liberty' – 'Sticky Bird free'
3. 'eleven plus two' – 'twelve plus one'	
4. 'dragon king' - 'going Darn'
5. 'the Morse Code' – 'here come dots'
6. 'the nudist colony' – 'no untidy clothes'

`;

// Exercise Solution:
let arr1 = ["dynaMite", "MaYitend"]; // T
let arr2 = ["Statue of Liberty", "Sticky Bird free"]; // F
let arr3 = ["eleven plus two", "twelve plus one"]; // T
let arr4 = ["dragon king", "going Darn"]; // FLAG
let arr5 = ["the Morse Code", "here come dots"]; // T
let arr6 = ["the nudist colony", "no untidy clothes"]; // T

// Solution I

function decodeMutations(arr) {
  let array1 = [];
  let array2 = [];
  array1.push(...arr[0]);
  array2.push(...arr[1]);
  const lowCase1 = array1.map((char) => char.toLowerCase());
  const lowCase2 = array2.map((char) => char.toLowerCase());
  let str1 = lowCase1.sort().join("");
  let str2 = lowCase2.sort().join("");
  console.log("c1 - dynamite:", lowCase1, "c2 - mayitend:", str2);
  if (str1 === str2) return true;
  else return false;
}

console.log("Exercise Solution I", decodeMutations(arr4));

function decodeMutations2(arr) {
  let comp2 = arr[1].toLowerCase();
  let comp1 = arr[0].toLowerCase();
  for (let i = 0; i < comp2.length; i++) {
    if (comp1.indexOf(comp2[i]) === -1) 
    return false;
    // console.log('evaluation:', comp1.indexOf(comp2[i]))
  }
   console.log('c1',comp1, 'c2',comp2)
  return true;
}

console.log("Exercise Solution II", decodeMutations2(arr4));

// BONUS find out which function has a bug 