// Course Notes:
document.getElementById("lesson").innerHTML = `
Group Objects by Values in JavaScript

A very useful tool when it comes to grouping ordered information by specific values 
is the filter method in JavaScript.

The filter method() creates a new array with all elements 
that pass the test implemented by a provided function 

// filter method - Arrow Functions ()=>
filter(item => {// check some truth} )
filter((item, index) => {// check some truth})
filter((item, index, array) => {// check some truth})

// filter method - Callback functions
filter(callback func)
filter(callback func, thisArg)

Example 1: Filter Method

`;

// Code Examples:

// Example 1: Filter Method

const words = ["ghost", "shoe", "note", "extraordinary"];

console.log(
  "Example 1",
  words.filter((word) => word.length > 5)
);

function filterFunc(word) {
  if (word.length > 5) {
    return true;
  }
  return false;
}

console.log("Example 1 CB", words.filter(filterFunc));

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise - Group Objects by Values in JavaScript

You are moved into the basement of a company and asked to do some data entry work. 

Yikes.

Since you have coding skills, you decide to write some algorithms instead to do the
work for you so you can get out of the basement and get an office with a window and
a view. 

1. Given the following array containing objects of company employee information:

employees = [
  {name: "Tony Stark", department: "Accounting"},
  {name: "Peter Parker", department: "Sushi Chef"},
  {name: "Bruce Wayne", department: "Accounting"},
  {name: "Clark Kent", department: "Mail Room"}
];

1. Write a function called groupingObjectsByValues which takes one array as an argument
called data and one object as an argument called department. 

2. The function must check through all the employee information in the data argument
and return into a new global array all the object data of only the accountant employees
including their name and department information. 

3. Call and log the groupingObjectsByValues passing in the employees array as the first
argument and select the department for grouping accordingly inputted as the s
econd object argument

Good luck getting out of that basement! 

`;

// Exercise Solution:

const accountantsArray = [];

const employees = [
  { name: "Tony Stark", department: "Accounting" },
  { name: "Peter Parker", department: "Sushi Chef" },
  { name: "Bruce Wayne", department: "Accounting" },
  { name: "Clark Kent", department: "Mail Room" },
  { name: "Donald Duck", department: "Accounting" }
];

function groupingObjectsByValues(data, department) {
  let srcValues = Object.values(department);
  console.log(srcValues);

  function runDepartmentTest(obj) {
    for (let i = 0; i < srcValues.length; i++) {
      if (Object.values(obj).indexOf(srcValues[i]) > -1) {
        return accountantsArray.push(obj);
      }
    }
    return false;
    // console.log(obj)
  }

  return data.filter(runDepartmentTest);
}

console.log(
  "Exercise Solution",
  groupingObjectsByValues(employees, { department: "Accounting" })
);

console.log('Accounting Department:',accountantsArray)
