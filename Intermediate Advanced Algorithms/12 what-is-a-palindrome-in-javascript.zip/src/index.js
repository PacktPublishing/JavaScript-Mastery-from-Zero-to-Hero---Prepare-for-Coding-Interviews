// Course Notes:
document.getElementById("lesson").innerHTML = `
What is a Palindrome in JavaScript

The difference between an anagram and a palindrome is than an anagram is (of words)
a word or a phrase that is created by rearranging the letters of another word or phrase
while a palindrome is a word, phrase, number, or any other sequence of units which
has the property of reading the same forwards as it does backwards, character for
character, sometimes disregarding punctuation, capitalization, and diacritics. 

IE a palindrome: 'eye' = palindrome, not a palindrome: 'eyes' = !palindrome

Example: RECALL the Anagram Exercise

`;

// Code Examples:

//Example: RECALL the Anagram Exercise

let arr2 = ["Statue of Liberty", "Sticky Bird free"]; // F

function decodeMutations(arr) {
  let array1 = [];
  let array2 = [];
  array1.push(...arr[0]);
  array2.push(...arr[1]);
  const lowCase1 = array1.map((char) => char.toLowerCase());
  const lowCase2 = array2.map((char) => char.toLowerCase());
  let str1 = lowCase1.sort().join("");
  let str2 = lowCase2.sort().join("");
  console.log("c1 - dynamite:", lowCase1, "c2 - mayitend:", str2);
  if (str1 === str2) return true;
  else return false;
}

console.log("Example 1", decodeMutations(arr2));

// Exercise
document.getElementById("exercise").innerHTML = `

Interview Question - Check if a string is a Palindrome 

1. Write a function called palindrome that takes a string as a parameter
that returns true if a word or phrase is a palindrome and false if a word
or phrase is not a palindrome.

2. NOTE that any non-alphanumeric characters (including the underscore) should
be disregarded (for example: ./[[]] should be disregarded).

3. Log and call the function twice passing in the following strings:
"// [_t  o t_]" expected output: true
" map" expected output: false

4. Share your solution in the discord and good luck! 

`;

// Exercise Solution:

function palindrome(str) {
  // \W = [ 0-9a-zA-Z_]
  let array1 = str
    .replace(/[^0-9a-z]/gi, "")
    .toLowerCase()
    .split("");
  let array2 = str
    .replace(/[^0-9a-z]/gi, "")
    .toLowerCase()
    .split("")
    .reverse();
  console.log(array1, array2);

  let str1 = array1.join("");
  let str2 = array2.join("");
  console.log(str1, str2);

  if (str1 === str2) {
    return true;
  } else {
    return false;
  }
}

console.log("Exercise Solution I", palindrome("// [_t  o t_]"));
console.log("Exercise Solution II", palindrome(" map"));
