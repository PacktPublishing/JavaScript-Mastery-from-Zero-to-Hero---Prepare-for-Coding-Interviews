// Course Notes:
document.getElementById("lesson").innerHTML = `

Modifying Arrays - Remove Items with pop and shift in JavaScript

We've looked at the push() and unshift() method to add elements to an array.
We can do the exact opposite in JavaScript with the pop() and shift() method
their spooooooky counterparts.

The pop() method will remove the last item in an array whereas the 
shift() method will remove the first item in an array. 

It's important to note that while push() and unshift() can take multiple 
arguments the pop() and shift() method do not take any methods. 

Ex 1 of pop and shift

`;

// Code Examples:
// Ex 1: pop() and shift() methods

let outdoorClothes = ["raincoat", "shoes", "hat", "umbrella"];
console.log("Example 1", outdoorClothes);
outdoorClothes.pop();
outdoorClothes.shift();

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise - Modify Arrays: Remove Items!

1. Write a function called eBooks which takes an argument array.
2. Log eBooks in the console and pass into the array the following books as strings:
Lord Of The Rings, Infinite Jest, Javascript, The Good Parts 
3. Within the eBook function, using the pop and shift methods, modify the array so that it
removes ONLY the Infinite Jest book. 
4. Share your solution in the discord. 

`;

// Exercise Solution:

function eBooks(arr) {
  // create two variables that store pop and shift
  let _pop = arr.pop();
  let _shift = arr.shift();
  return [_pop, _shift];
}

console.log(
  "Exercise Solution",
  eBooks(["Lord of The Rings", "Infinite Jest", "JavaScript, The Good Parts"])
);
