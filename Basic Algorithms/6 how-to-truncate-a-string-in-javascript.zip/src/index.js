// Course Notes:
document.getElementById("lesson").innerHTML = `
How to Truncate a string in JavaScript

In mathematics and in computer science, truncation is limiting
the number of digits to the right of a value. 

let x = 'hello'
We can slice off the o to truncate x in order for it to equal = 'hell' 

The slice() method in javaScript is an excellent tool for truncation. 

`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `
Exericse Truncate - Paywall Text Algorithm: 

You're working at a Blob The Blog Blog company and they are putting up a 
paywall to restrit guest viewers from reading the full article. 

Truncate the text so that it only returns up to a maximum value and replaces the 
additional overflow with '...'

1. Write a function truncate which takes a string and number as arguments and returns
the string truncated determined by the value of the number argument. 

Ex: string = 'hello', num = 3 then expected output = 'hel'

2. Log the result in the console and pass in the arguments:
"Really important stuff you'll pay to read", 21

Guten luck! 

`;

// Exercise Solution:

function truncate(str, num) {
  if (str.length >= num) {
    return str.slice(0, num) + "...";
  }
  return str;
}

console.log(
  "Exercise Solution",
  truncate("Really important stuff you'll pay to read", 21)
);
