// Course Notes:
document.getElementById("lesson").innerHTML = `
Virus Detection Algorithm - Asymmetric Arrays 

Callback Functions: 
A callback function is a function passed into another function as an 
argument, which is then invoked inside the outer function to complete 
some kind of action.

Example 1: Calling a Function within a function

`;

// Code Examples:

// Example 1: Calling a Function within a function

function Example() {
  let greeting = "";
  function callB() {
    greeting = "hello";
  }
  callB();
  return greeting;
}

console.log(Example());

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise - Virus Detection Algorithm - Asymmetric Arrays 

You are working client side for a successful start up company. You even have a fooseball table
in the lounge, but it doesn't even matter because you can work remotely on the beach. 
Lucky you!

Some hackers get into the client side and implant viruses into the userbase with false accounts.
You boss asks you to locate and track down wihch accounts are causing the malevolent attacks.

Using the cloud database you begin a search to isolate the accounts which do not belong and 
track down the bad actors before it's too late. 

1. Assign the usersCloud array and usersClient arrays with the following data. 

usersCloud = ['tom','susan','jordan','lucy','abraham','jose','maria'];

let usersClient = ['tom','susan', 'VIRUS', 'jordan',
'lucy', 'VIRUS', 'abraham', 'TROJAN','jose','maria'];

2. Create a function virusDetection that can search through two arrays and return a new
array of all the non equal elements in either array 
(ie. any element in one array which does not exist in the other array and vice versa.)

3. Call and log the function virusDetection 
passing in the two arrays usersCloud and usersClient 

4. Share your solution in the discord in the #algorithm channel.

Good luck and show these hackers what's up! 
`;

// Exercise Solution:

let usersCloud = ["tom", "susan", "jordan", "lucy", "abraham", "jose", "maria"];

let usersClient = [
  "tom",
  "susan",
  "VIRUS",
  "jordan",
  "lucy",
  "VIRUS",
  "abraham",
  "TROJAN",
  "jose",
  "maria"
];

function virusDetection(arr1, arr2) {
  const newArr = [];

  function onlyInFirst(firstArray, secondArray) {
    for (let i = 0; i < secondArray.length; i++) {
      if (firstArray.indexOf(secondArray[i]) === -1) {
        newArr.push(secondArray[i]);
      }
    }
  }

  onlyInFirst(arr1, arr2);
  onlyInFirst(arr2, arr1);

  return newArr;
}

console.log(virusDetection(usersClient, usersCloud));
