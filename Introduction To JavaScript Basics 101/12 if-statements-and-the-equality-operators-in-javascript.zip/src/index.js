// Course Notes:
document.getElementById("lesson").innerHTML = `

The if/else statement executes a block of code if a specified 
condition is true (boolean). If the condition is false, another block of 
code can be executed. The if/else statement is a part of 
JavaScript's "Conditional" Statements, which are used to perform 
different actions based on different conditions.

Booleans are datatype which contain true or false values 

let isItRaining = true;


Equality Operators are different than assigment
Assignment Ex: let x = 2;
Equality Operators include: ==, ===, < > <= >=
Ex: x > y, a <= b
`;

// Code Examples:

const x = 2;
const y = 3;

function conditional() {
  if (x < y) {
    return true;
  } else {
    return false;
  }
}

console.log(conditional());

// Exercise
document.getElementById("exercise").innerHTML = `

Create a timetravel program that can send us back in time! Woohoo

1. Create two const global variables speed and time and initialze speed
and time to any numbers as long as time is less than speed

2. Create an additional reassignable variable called loadData as a boolean
and initialize it to false. 

Now we have our global programming variables set up and it's time to 
set the wheels in motion!. 

3. Write a function timeTravel that takes two arguments x and y. Add
conditional logic to the function that checks whether x is greater than
or equal to y. If this is true then return the function so that loadData
is modified to true. If it's false then return loadData explicitly again
to equal false. 

4. Write a second function called nebular that checks to see if loadData
is true or false. If it's true then nebular should run a console log with 
the string input: "Welcome to the stone age!"

5. Execute both functions inputting speed and time as 
arguments for timeTravel setting speed to x and time to y. 

6. Once you succeed in finishing the program watch our for 
dinosaurs in the stone age and yabadabadoooooo

`;

// Exercise Solution:

const speed = 2;
const time = 1;

let loadData = false;

console.log("the state of loadData before:", loadData);

function timeTravel(x, y) {
  if (x >= y) {
    return (loadData = true);
  } else {
    return (loadData = false);
  }
}

function nebular() {
  if (loadData) {
    console.log("Welcome to the stone age!!!");
  }
}

timeTravel(speed, time);

nebular();

console.log("the state of loadData after:", loadData);
