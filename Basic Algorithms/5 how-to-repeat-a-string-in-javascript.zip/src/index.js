// Course Notes:
document.getElementById("lesson").innerHTML = `
How to Repeat A String in JavaScript

'hello' repeat 4 times = 'hellohellohellohello'

There are many ways you could go about repeating a string in JavaScript.

The repeat() method is a nice trick introduced in 2015 among others.

Supported Browsers: 

    Google Chrome 41 and above
    Edge 12 and above
    Firefox 24 and above
    Opera 28 and above
    Safari 9 and above
`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise: Repeat A String in JavaScript

1. Write a function repeatString which takes two arguments, a string and a number 
and return a new string repeating the function's argument string 
as many times as the number argument specifies. 

2. Log the result in the console and share your solution in the discord. 
`;

// Exercise Solution:

// Solution I

function repeatString(str, num) {
  return str.repeat(num);
}
console.log("Exercise Solution I", repeatString("kangaroo", 7));

// Solution II

function repeatString2(str, num) {
  let array = [];
  for (let i = 0; i < num; i++) {
    array.push(str);
  }
  return array.join("");
}
console.log("Exercise Solution II", repeatString2("kangaroo", 7));

// Solution III

function repeatString3(str, num) {
  return Array(num).fill(str).join("");
}
console.log("Exercise Solution III", repeatString3("kangaroo", 7));
