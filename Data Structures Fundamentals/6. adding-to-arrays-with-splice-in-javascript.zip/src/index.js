// Course Notes:
document.getElementById("lesson").innerHTML = `
Adding to Arrays with Splice in JavaScript

We've seen how the first two arguments of splice
are used for selecting a starting position and
then removing a number of elements in an array.
Splice also takes a third argument as well.

The third argument of the splice method allows you
to swap out the elements you are removing with new
variables at the position that you set.

Ex 1: The Splice Method Third Argument

`;

// Code Examples:
// Example 1: The Splice Method Third Argument (Swapping in new elements)

let fixMePlease = ["this", "sentence", "broken", "pie", "now"];
fixMePlease.splice(2, 2, "is", "fixed");
console.log("Example 1:", fixMePlease);

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise Update User Names with Splice 
1. Declare the function updateUserNames which takes an array as an argument and return 
the array.
2. Log to the console updateUserNames and append the following string literal names
to the array: 'Thomas', 'Suzie','Jessica','Jonny'
3. Back in the updaetUserNames function, update the user names of the array by replacing
'Suzie' with the new user 'Bob' using the splice method.
4. Dub yourself victorious, Apprentice level up!  

`;

// Exercise Solution:

function updateUserNames(array) {
  array.splice(1, 1, "Bob");
  return array;
}
console.log(
  "Exercise Solution:",
  updateUserNames(["Thomas", "Suzie", "Jessica", "Jonny"])
);
