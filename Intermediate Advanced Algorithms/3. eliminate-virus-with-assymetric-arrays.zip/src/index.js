// Course Notes:
document.getElementById("lesson").innerHTML = `
Eliminate Virus with Assymetric Arrays

`;

// Code Examples:

// Example 1: Calling a Function within a function

function Example() {
  let greeting = "";
  function callB() {
    greeting = "hello";
  }
  callB();
  return greeting;
}

console.log(Example());

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise - Eliminate Virus with Assymetric Arrays

Now that we have successfully isolated the inconsistences of symmetry from
our client side to the cloud data, let's create additional functionality
to eliminate the viruses once and for all. 

1. Refactor the solution code from the last exercise - Virus Detection so
that the virusDetection function pushes the inconsistencies of symmetry between 
the usersCloud aray and the usersClient into a global array detectArr. 

2. Write a function called eliminateVirus which can check through the detectArr
inconsistencies against the usersClient data and permanently delete all the original 
inconsistent elements in the usersClient array.

Share your solution on the discord in the algorithms channel

Good luck!

`;

// Exercise Solution
let usersCloud = ["tom", "susan", "jordan", "lucy", "abraham", "jose", "maria"];

let usersClient = [
  "tom",
  "susan",
  "VIRUS",
  "jordan",
  "lucy",
  "VIRUS",
  "abraham",
  "TROJAN",
  "jose",
  "maria"
];

// detectArr = ['VIRUS','VIRUS','TROJAN']

const detectArr = [];

virusDetection(usersClient, usersCloud);

function eliminateVirus(arr1, arr2) {
  for (let i = 0; i < arr1.length; i++) {
    for (let j = 0; j < arr2.length; j++) {
      if (arr1[i] === arr2[j]) {
        arr1.splice(i, 1);
      }
    }
  }
  return arr1;
}

function virusDetection(arr1, arr2) {
  function onlyInFirst(firstArray, secondArray) {
    for (let i = 0; i < secondArray.length; i++) {
      if (firstArray.indexOf(secondArray[i]) === -1) {
        detectArr.push(secondArray[i]);
      }
    }
  }

  onlyInFirst(arr1, arr2);
  onlyInFirst(arr2, arr1);

  return detectArr;
}

// console.log(virusDetection(usersClient,usersCloud));

console.log("Exercise Solution", eliminateVirus(usersClient, detectArr));
