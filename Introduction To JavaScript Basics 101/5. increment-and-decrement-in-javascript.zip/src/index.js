// Course Notes:
document.getElementById("lesson").innerHTML = `
Another easy way to increment and decrement numbers
in JavaScript is with the operators ++ and --
`;

// Code Examples:

let i = 7;
i++;
console.log("Example:", i);

// Exercise
document.getElementById("exercise").innerHTML = `

1. Create a resassignable ES6 variable y which is not read only
and assign it the value of 4. 
2.  Subtract 1 from y using the decrement operator and 
console log the result

`;
// Exercise Solution:

let y = 4;
y--;
console.log("Solution:", y);
