// Course Notes:
document.getElementById("lesson").innerHTML = `
Slice is a method which can copy an array's data to new storage
without modifying the original array. 

Slice can take two arguments. The first argument is the position
to start copying data and the second argument indicates where we
stop copying data (up to and NOT including the index value)

Ex 1: How To Copy an Array with Slice 
`;

// Code Examples:
// Example One: How To Copy an Array with Slice

let trainingData = ["10,000 steps", "7 JavaScript exercises", "4 React videos"];
let codingData = trainingData.slice(1, 3);
console.log(
  "Example 1:",
  "codingData:",
  codingData,
  "trainingData:",
  trainingData
);

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise: Update CryptoCurrency Portfolio Data

1. Declare a function called cryptoPortfolio which returns the argument array of an array.
2. Log out cryptoPortfolio into the console passing the following crypto data as strings:
'Bitcoin', 'Ethereum', 'Solana', 'Ada', 'Chainlink' 
3. Within the crpyotPortfolio function, duplicate our user's 
crypto portfolio of only the large caps (Bitcoin and Ethereum) 
into a new array called newArray and modify the function so that it 
returns the new array instead of the original one. 
4. Share your solution in our discord in the #datastructures channel.
5. Good luck and may the defi be with you!
`;

// Exercise Solution:

function cryptoPortfolio(array) {
  let newArray = array.slice(0, 2);
  return newArray;
}

console.log(
  "Exercise Solution",
  cryptoPortfolio(["Bitcoin", "Ethereum", "Solana", "Ada", "Chainlink"])
);
