// Course Notes
document.getElementById("lesson").innerHTML = `
Checking Object Properties in JavaScript

We can use the hasOwnProperty method in javaScript to check whether
a property exists in a object. hasOwnProperty will return a value of
true if it exists and false if it does not.

Example 1: Check whether a property exists 
`;

// Code Examples:
// Example 1: Check whether a property exists

const restaurant = {
  salad: "romaine",
  burgers: true
};

delete restaurant.burgers;
console.log("Example 1", "burgers" in restaurant);
console.log("Example 1", restaurant.hasOwnProperty("burgers"));

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise: Fix a Bug for A Medical Company's Data 

You work at a medical company and you've been getting this weird bug 
where the data property 'fever', of whether a patient has a fever 
has been oddly and mistakenly replaced with the property 'shoes'.

const medicalData = {
  perscriptions: true,
  weight: 156,
  height: 508,
  shoes: false
};

Your boss says he spoke with the doctors and you need to fix this confusing information
ASAP so as not to distract the doctors from their hard work.

1. Write a function cleanUp which will check whether an object contains the property
shoes and delete it if it does. Additionally, create and assign the value of the 
property shoes to a new property fever. 

2. Log out the solution and share it with the discord! :)

The medical communnity is counting on you! ;) Good luck.`;

// Exercise Solution:

const medicalData = {
  perscriptions: true,
  weight: 156,
  height: 508,
  shoes: true
};

function cleanUp(obj) {
  if (obj.hasOwnProperty("shoes")) {
    obj.fever = obj.shoes;
    delete obj.shoes;
  } else {
    return "shoes not found as a property withtin the object";
  }
  return obj;
}

console.log("Exercise Solution", cleanUp(medicalData));
