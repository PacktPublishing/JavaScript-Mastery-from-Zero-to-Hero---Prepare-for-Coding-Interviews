// Course Notes:
document.getElementById("lesson").innerHTML = `

In computing, data is information that has been translated into a form 
that is efficient for processing. 

JavaScript has 8 different data types for processing:

undefined, null, boolean, string, symbol, bigent, number, 
object

When you declare a variable in javaScript, you specify the data type
and you store the value 

In order to create a variable with JavaScript we use the keyword  b

a string: stores a series of characters with quotations: single ''
or double quotations: ''

a string: 'would be any characters' whereas a number would be any whole number

Just like in algebra how was use a and b to store values: a = 3, b = 2, a + b = 5

`;

// Code Examples:

// string examp[e:
var hello = "Welcome!";

var goodbye = "Peace oot!";

console.log("Exercicse:", goodbye);

// Exercise
document.getElementById("exercise").innerHTML = `

Declare a variable as a number and set it to the number 5
then console log the variable and check that the output equals 5
`;

// Exercise Solution:

var number = 5;

console.log("Solution:", number);
