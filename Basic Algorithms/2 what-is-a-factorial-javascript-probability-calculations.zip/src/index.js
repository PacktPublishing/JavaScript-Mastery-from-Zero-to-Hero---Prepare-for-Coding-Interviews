// Course Notes:
document.getElementById("lesson").innerHTML = `

What is A Factorial - JavaScript (Probability Calculations)

What is factorializing a number and why is this valuable?

Factorials help us to calculate probabilities 

Consider having combination of puzzle peices and you'd like 
to know all the possible combinations that these peices could 
form.

['puzzle peice 1','puzzle peice 2','puzzle peice 3']

A factorial, by definition, is the product of all positive integers less than
or equal to n

Factorials in math are denoted with the shorthand notation: n!

Example 1: What is the factorial of 4

n!, n = 4, 4! = 4 * 3 * 2 * 1 = 24

`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise: What is A Factorial - JavaScript (Probability Calculations)

1. Declare a function called factorialize which takes a number as an argument.
The function should return the factorial product of the number. 

Ie: 4! = 24, 5! = 120 etc

2. Call the function in the console and pass in 7 as the argument and log out the result.

3. Share your solution in the discord and well done!  

`;

// Exercise Solution:
function factorialize(num) {
  let product = 1;
  for (let i = 1; i <= num; i++) {
    product *= i;
  }
  return product;
}

console.log("Exercise Solution", factorialize(7));
