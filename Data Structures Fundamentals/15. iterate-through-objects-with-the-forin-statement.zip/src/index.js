// Course Notes:
document.getElementById("lesson").innerHTML = `
Iterate through Objects with the for...in statement

The for...in statement iterates over all enumerable properties of an object that are 
keyed by strings, including inherited enumerable properties. 

Example 1: Iterating through an Object with for..in

`;

// Code Examples:

// Example 1: Iterating through an Object with for..in

let npc = {
  character: "knight",
  weapon: "enchanted long sword",
  beard: true
};

for (let attributes in npc) {
  console.log("Example 1", attributes);
  console.log("Example 1", npc[attributes]);
}

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise: Login Iteration Calculator 

Given the following object of login information:

let logins = {
  week1: true,
  week2: false,
  week3: true,
  week4: true,
  week5: true
};

1. Write a function which can calculate and return the total number of logins 
using a for...in statement from this given object. 

And that's all she wrote, folks!
`;

// Exercise Solution:

let logins = {
  week1: true,
  week2: false,
  week3: true,
  week4: true,
  week5: true
};

function calcLogins(obj) {
  let num = 0;
  for (let week in obj) {
    if (obj[week] === true) num += 1;
  }
  return num;
}

console.log("Exercise Solution", calcLogins(logins));
