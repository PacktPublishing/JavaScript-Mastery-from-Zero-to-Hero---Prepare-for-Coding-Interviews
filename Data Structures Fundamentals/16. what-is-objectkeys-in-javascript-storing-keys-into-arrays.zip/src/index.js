// Course Notes:
document.getElementById("lesson").innerHTML = `
What is Object.keys in JavaScript - storing keys into arrays

You can store all the keys in an object into an array with the Object.keys() method. 
Objects.keys takes one argument which is the object you wish to extract the keys from.

Example 1: How to copy keys from an object into an array 

`;

// Code Examples:
// Example 1: How to copy keys from an object into an array

let languages = {
  french: true,
  english: false,
  spanish: true
};

console.log("Example 1:", Object.keys(languages));

// Exercise
document.getElementById("exercise").innerHTML = `

Write some objects and store their keys into arrays with Objects.keys and don't
forget to have some fun along the way! 


`;

// Exercise Solution:
