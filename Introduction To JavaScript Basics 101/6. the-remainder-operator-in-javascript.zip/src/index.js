// Course Notes:
document.getElementById("lesson").innerHTML = `

If we want to find the remainder of the division of two numbers
We can use the remainder operator in JavaScript

The remainder operator is the percentage sign: %

The division of two numbers yields the quotient 4 / 2 = 2;
If you take 4 and you split it into two groups you have one group
group A has 2, ,and another group, group B has 2. 
What is the remainder?

We can use mathametics to check whether a number is even or odd
with the remainder of the division of the number by 2.

`;

// Code Examples:

console.log("example 1", 4 % 2);
console.log("example 2", 7 % 4);
// group A = 1 group B = 1 group C = 1 group D = 1
// 7 - 4 = 3 R = 3
console.log("example 3", 7 % 3);
// group A = 2 group B = 2 group C = 2
// 7 - 6 = 1 R = 1

const x = 10;
console.log("example check even or odd", x % 2);

// Exercise
document.getElementById("exercise").innerHTML = `

Declare a read only variable remainder equal to the remainder 
of 4 divided by 1 using the remainder operator.

Log the result and make an assessment of the number 4!

`;

// Exercise Solution:

const remainder = 4 % 1;

console.log("Solution:", remainder);
