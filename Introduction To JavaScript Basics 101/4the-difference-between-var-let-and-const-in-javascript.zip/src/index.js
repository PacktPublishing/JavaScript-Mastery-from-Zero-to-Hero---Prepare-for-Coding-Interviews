// Course Notes:
document.getElementById("lesson").innerHTML = `
An issue with using var to declare variables is that it can easily be over written

ES6, which was a update standardization to JavaScript addressed this issue by introducting
the let variable. If we replace var with let we will then get an error to avoid making the
mistake

let is a great way to remove the possibility of accidentally redefining variables but
ES6 didn't stop there. It gave JS another awesome gift by introducing the const variable

The const variable has all the same features as let but it also is read only. That means
that you can't accidentally reassign the const variable without throwing an error. 

`;

// Code Examples:
//var cat = "meow";
//var cat = "woof";

// read only vs reassignable
let yourbestfriend = "tom";
yourbestfriend = "susan";

const yourworstenemy = "jack";
//yourworstenemy = "Fredc";

let cat = "woof woof";
console.log("Example:", cat);

// Exercise
document.getElementById("exercise").innerHTML = `

1. Create a read only variable x and assign it the string 'this is read only' 
`;

// Exercise Solution:

const x = "this is read only";
console.log("Solution:", x);
