// Course Notes:
document.getElementById("lesson").innerHTML = `
Data Structures - Fundamentals!

What are arrays?
Arrays store collections of data. One dimensional arrays
only have one level (nests).
Arrays in Javascript can contain multiple types: booleans,
integers, strings

The length (length) property returns the number of elements
within an array 

Arrays can get much more complex!
These are what we would call multi-dimensional arrays (arrays
  that contain other arrays). Observe that arrays can even contain 
  complex objects.

`;

// Code Examples:

// Array Example:
let loader = true;
let oneDimArray = [loader, 4, "cat"];
console.log("result is of oneDimArray:", oneDimArray.length);

// Complex Array Example:

let multiDimArray = [
  [
    {
      mexico: "Mexico",
      russia: "Russia"
    },
    {
      hot: true,
      cold: false
    }
  ],
  [
    {
      cat: "cat",
      dog: "dog"
    },
    {
      cute: true,
      cuddly: false
    }
  ]
];

//Exercise
document.getElementById("exercise").innerHTML = `
Array Exercise:
1. Write an array called simpleArray and assign it 6 different variables.
2. In order to pass this exercise the array must contain at least 1 
boolean, two strings and one integer
3. Log out the length of the array in the console.

Post solution in the #datastructures
`;

// Exercise Solution:
let simpleArray = [true, "lion", "tiger", "bear", 1, 2];

console.log("result of simpleArray is: ", simpleArray.length);
