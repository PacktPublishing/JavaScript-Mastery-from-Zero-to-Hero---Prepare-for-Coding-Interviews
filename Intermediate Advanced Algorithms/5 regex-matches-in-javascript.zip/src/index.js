// Course Notes:
document.getElementById("lesson").innerHTML = `
Regex matches in JavaScript

Regular Expressions are patterns used to match characters
or character cominbations in strings. 

In JavaScript, Regaular Expressions are also objects. 

Grouping: a grouping is basically like a mini-regex inside
a pair of parenthesis, while a character set is a range
between square brackets 

IE:
/([a-z])([A-Z])/g

The above example captures: one character a-z
and one character A-Z

Example 1: Regex pattern matching and replacing 
`;

// Code Examples:
// Example 1: Regex pattern matching and replacing

let str = "ThreeTwo = Five";

console.log(
  "Example 1:",
  str.replace(/([a-z])([A-Z])/g, function (match, g1, g2) {
    return g1 + " + " + g2;
  })
);

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise - Star Power with Regex in JavaScript

You are working for a website called Star Power and they just can't get enough
stars. They loves stars so much in fact, so much that they want you to design an
algorithm which will replace all string grouping of upper and lowercases with spaces 
following by an asterix in between. 

Strange request? - Perhaps! But sometimes we just gotta do what the job requires. 

For Example - 
Given the following string: 'starPower Forever', we should replace it with:
star * power * forever

1. Write a function starPowerAlgo which takes a string as an argument and returns a
new string in all lowercase.

2. The function should replace all groupings of uppercases and lowercases with a space
and should also replace all spaces with an asterix. 

IE: The string 'starPower Forever' should be replaced with 'star * power * forever'

2. Call and log the function passing in 'starPower Forever'

Share your solution on the discord and good luck!`;

// Exercise Solution:

function starPowerAlgo(str) {
  let convertedStr = str.toLowerCase().split(' ');
  let asterix = [];

  for(let i = 0; i < convertedStr.length; i++) {
    asterix += convertedStr[i] + ' * ';
  }
    let array = asterix.toString().split('').splice(0, asterix.length - 3)
    let string = array.join('')
  /*
  convertedStr = str
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toLowerCase()
    .split(" ");
  return convertedStr.join(" * ");
  */
 return string
}

console.log("Exercise Solution", starPowerAlgo("starPower Is alwaysAnd Forever"));

// 'starPower Forever' - EO: 'star * power * forever'
