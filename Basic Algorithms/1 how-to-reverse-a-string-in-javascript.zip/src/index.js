// Course Notes:
document.getElementById("lesson").innerHTML = `
How to reverse a string in JavaScript

Helper Examples:

The split() method splits a string into an array of substrings, and returns the new array.

The reverse() method reverses an array in place. 
The first array element becomes the last, and the last array element becomes the first. 

The join() method creates and returns a new string by concatenating all of the elements 
in an array (or an array-like object), separated by commas or a specified separator string. 

`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise: How to reverse a string in JavaScript

1. Write a function which takes the argument of a string and returns another string which holds
the reverse order of characters of the original argument string.

2. Call the function in the console and test your solution with the argument 
'The universe is amazing'

3. Share your solution in the discord channel #algorithms
`;

// Exercise Solution:

// Solution 1
function reverseString(str) {
  return str.split("").reverse().join("");
}
console.log("Solution 1", reverseString("The universe is amazing"));

// Solution 2
function reverseString2(str) {
  let revStr = "";
  for (let i = str.length - 1; i >= 0; i--) {
    revStr += str[i];
  }
  return revStr;
}

console.log("Solution 2", reverseString2("The universe is amazing"));
