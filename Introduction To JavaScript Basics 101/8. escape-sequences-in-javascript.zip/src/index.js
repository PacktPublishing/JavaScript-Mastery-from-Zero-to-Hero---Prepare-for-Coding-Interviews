// Course Notes:
document.getElementById("lesson").innerHTML = `

Escape literals allow us to use quotations and change the indenting
in our strings so that JavaScript can format the strings properly 

\' = 	single quote 
\" =	double quote
\\ =	backslash
\n =	newline
\t =	tab

`;

// Code Examples:

let hello = "jesse welcome's you";
console.log("example single quote", hello);
console.log('tom told me today, "stop being lazy!" ');

// Exercise
document.getElementById("exercise").innerHTML = `
Log a console message with the following sentence: 'the cat
jumped over the moon' so that each word starts on a new line
`;

// Exercise Solution:

console.log("Solution:", "the \ncat \njumped \nover \nthe \nmooon");
