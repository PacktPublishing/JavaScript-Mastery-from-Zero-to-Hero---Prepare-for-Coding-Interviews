// Course Notes:
document.getElementById("lesson").innerHTML = `
How To Copy an Array with the Spread Operator in JavaScript

If you just want to simply copy all of an array's data
with making specifications we can easily employ ES6's very helpul method,
the spread operator. 

Simple and easy syntax: ...

Example 1: How to copy an array with the spread operator

`;

// Code Examples:
// Example 1: How to copy an array with the spread operator

let weatherReport = ["cold", "13 degrees", "cloudy", "incoming tornado"];
let copyWeatherReport = [...weatherReport];
console.log("Example 1", copyWeatherReport);

// Exercise
document.getElementById("exercise").innerHTML = `
Exercise: Make multiple copies of an array with the spread Operator 
1. Declare a variable called numberofCopies and set the value to 4.
2. Create a function called makeFourCopies which takes an argument array as an array. 
3. Log into the console the function makeFourCopies passing into it the following string
data: 'gains', 'losses', 'losses'
4. Back in the makeFourCopies function, write the logic
in order to make multiple copies of the array data (
make the EXACT amount of copies as the value in numberOfCopies) into
a new array return the new array and share your solution on the discord.
Good luck!
`;

// Exercise Solution:

let numberOfCopies = 4;

function makeFourCopies(array) {
  let newArray = [];
  for (let i = numberOfCopies; i > 0; i--) {
    newArray.push([...array]);
  }
  return newArray;
}

console.log("Exercise Solution", makeFourCopies(["gains", "losses", "losses"]));
