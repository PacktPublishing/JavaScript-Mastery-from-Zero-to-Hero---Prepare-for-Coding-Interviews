// Course Notes:
document.getElementById("lesson").innerHTML = `
As we've discussed multiple times already in this course, functions
in JavaScript are the most efficient ways to reuse code and it's what 
makes them imperative in programming!

You can pass values in functions as arguments as well
`;

// Code Examples:

// functions are reusable code that take inputs and return
// outputs

function execute() {
  console.log("Example 1: Success!");
}
execute();

const x = 3;
const y = 2;

function execute2(num1, num2) {
  return num1 + num2;
}

console.log("example 2:", execute2(12, y));

// Exercise
document.getElementById("exercise").innerHTML = `

1. Write a function called calculator that takes any three numbers as
arguments and returns the product of all three numbers

2. Log the result of the function with the following numbers and 23, 44, 12
and find the solution 

`;

// Exercise Solution:

function calculator(a, b, c) {
  return a * b * c;
}

console.log("Solution:", calculator(23, 44, 12));
