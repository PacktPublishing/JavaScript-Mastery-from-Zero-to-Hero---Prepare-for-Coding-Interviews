// Course Notes:
document.getElementById("lesson").innerHTML = `
Generate Missing Alphabet Letters

We can leverage the charCodeAt() method which will return an integer between 0 and 65535 
representing the UTF-16 code unit at the given index. 

Now, while it may prove cumbersome to go through characters when it comes to modifying
string values for various purposes, by having a clear understanding of their UTF codes
and how we can manipulate them, we can render this process much more efficient and gain
real flexibility.

Examples: UTF-16 values 


`;

// Code Examples:
// Examples: UTF-16 values

console.log('Example I', 'abc'.charCodeAt(0))
console.log('Example II', String.fromCharCode(97))

// Exercise
document.getElementById("exercise").innerHTML = `

Exercise: Generate Missing Alphabet Letters

You are at an interview and the interviewer asks you how familiar 
you are with UFT in JavaScript. It's time to show them your skills...

1. Write a function generateLetters which takes a string as an argument.

2. The function should be able to input any given two alphabet letters and output 
all of the missing alphabet letters in between the two letters including the original
input in the correct alphabetized order. 

For Ex: 
Input: 'ad', Expected output: 'abcd'

3. Log and call the function passing in the string 'ap'

4. Share your solution in the discord in the #algorithms channel and good luck!
`;

// Exercise Solution:

function generateLetters(str) {
    let alpha = '';

    for(let i = 0; i < str.length; i++) {
      let code = str.charCodeAt(i);

      if(code !== str.charCodeAt(0) + i) {
        let letterDifference =  code - str.charCodeAt(0) + i;
        letterDifference *= -1
        console.log(letterDifference)

        for(let i = 0; i < letterDifference; i++) {
          alpha += String.fromCharCode(code -= 1);
        }
      }
    }

    let reverseAlpha = alpha.split('').reverse().join('')
    return str[0].concat(reverseAlpha).concat(str[1]); 
}

console.log('Exercise Solution', generateLetters('az'))