// Course Notes:
document.getElementById("lesson").innerHTML = `

Augmented assignment operators ( +=, -= *=, /= ) mathametically changes the value of 
the right operand to a variable and assigns the result to the 
variable. The types of the two operands determine the behavior of 
the assignment operator.

-----
what the heck am i even talking about?? IN ENGLISH PLEASE - 

You can assign a variable it's current memory state and then make a 
mathematical change to it to modify the variable. This happens quite often
in coding. Ex1

The short hand form of this would be with augmented operators as follow: 
Ex2

`;

// Code Examples:

let x = 5;
x = x + 4;
// x+= 4;
console.log("example 1", x);

let y = 5;

// y += 4 is the same as y = y + 4
y += 4;
console.log("example 2", y);

// Exercise
document.getElementById("exercise").innerHTML = `

Declare a reassignable variable a and set it to 10;
Using the augmented product operator multiply a (is the variabler) 
by a number which will yield the result 40.

Log the response and share it on the discord! 

`;

// Exercise Solution:

let a = 10;
a *= 4;
// a = a * 4;

console.log("Solution:", a);
