// Course Notes:
document.getElementById("lesson").innerHTML = `
Return The Smallest Numbers in Nested Arrays

Let's challenge our ability to work with nested and multi-dimensional arrays
as well as our understanding of backet notation

Example 1: Math.min()

The Math.min() method returns the number with the lowest value.

Another tip: Math.max() returns the number with the highest value.

`;

// Code Examples:
// Example 1: Math.min()

const array = [0, 1, 2, 3, 4, 5];

console.log("Example 1", Math.min(...array));

// Exercise
document.getElementById("exercise").innerHTML = `

Given the following multi-dimensional array:

const multiArray = [[234,35,2,1],[53,3,6554,4],[45,632,31,566]]

1. Write a function smallestNumbers which takes a multi dimensional array as an argument and 
returns a new array containing only the smallest integers from each sub array. 

2. Log out the function and pass in multiArray as the argument.

3. Share your solutions in the discord channel #algorithms 

`;

// Exercise Solution:

const multiArray = [
  [234, 35, 2, 1],
  [53, 3, 6554, 4],
  [45, 632, 31, 566]
];

function smallestNumbers(arr) {
  let newArr = [];
  for (let i = 0; i < arr.length; i++) {
    // arr[i] selects the sub arrays and Math.min selects the lowest values
    newArr.push(Math.min(...arr[i]));
  }
  return newArr;
}

console.log("Exercise Solution", smallestNumbers(multiArray));
