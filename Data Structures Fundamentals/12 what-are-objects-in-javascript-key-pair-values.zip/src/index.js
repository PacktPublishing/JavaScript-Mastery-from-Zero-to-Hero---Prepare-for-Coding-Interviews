// Course Notes:
document.getElementById("lesson").innerHTML = `

What Are Objects in JavaScript - Key/Pair Values

In JavaScript, an object is a standalone entity, with properties and type. 
Compare it with a car, for example. A car is an object, with properties. 
A car has a color, a design, engine, a material it is made of, etc. 
The same way, JavaScript objects can have properties, which define their characteristics.

Example 1: A Basic JavaScript Object

`;

// Code Examples:
// Example 1: A Basic JavaScript Object

const instagramUser = {
  handle: "@coolGuy46",
  photos: ["cat", "family", "car"],
  businessAccount: false
};

console.log("Example 1:", instagramUser);
// We can add properties with bracket and dot notation to objects

instagramUser.location = "France";
instagramUser["followers"] = 6;

// Exercise
document.getElementById("exercise").innerHTML = `
Build an Uber app customer javascript object datatable.

1. Write an object called uberCustomer
2. The object needs to take a minimum of 5 properties with values.
3. The properties and values can be whatever you think would be most appropriate
as long as the values are not blank.
4. At least two of the properties and values should be added with either bracket
or dot notation. 
5. Share your solution with the discord community! 

`;

// Exercise Solution:

const uberCustomer = {
  name: "Suzie Gomez",
  location: "New York",
  totalRides: 26
};

console.log("Exercise Solution:", uberCustomer);

uberCustomer.creditCard = "Mastercard";
uberCustomer["rating"] = 4.3;
