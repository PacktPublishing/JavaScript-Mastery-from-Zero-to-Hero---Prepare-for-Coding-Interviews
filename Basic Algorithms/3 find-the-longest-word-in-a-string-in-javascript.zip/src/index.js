// Course Notes:
document.getElementById("lesson").innerHTML = `

Another classic algorithm scripting challenge! 
Program the computer to identify the longest word in a string! 
We can do it with our minds and so why not ask our robot friends as well.
`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `
You are at a coding interview, the interviewer sits you down and asks you to find
the longest word in a string with JavaScript. 

1. Declare a function longestWord which takes an input of a string and returns
the longest word in the string. 

It's up to you to impress them with your skills and land the golden job! 
`;

// Exercise Solution I:

function longestWord(string) {
  let str = string.split(" ");
  let longest = 0;
  let word = "";
  for (let i = 0; i < str.length; i++) {
    if (longest < str[i].length) {
      longest = str[i].length;
      word = str[i];
    }
  }
  return word;
}
console.log(
  "Exercise Solution I",
  longestWord("if you get this right we will definitely hire you")
);

// Solution II

function longestWord2(string) {
  let str = string.split(" ");
  let longest = 0;
  let word = "";
  str.forEach(function (str) {
    if (longest < str.length) {
      longest = str.length;
      word = str;
    }
  });
  return word;
}
console.log(
  "Exercise Solution II",
  longestWord2("get the amazing bonus for solving this!")
);
