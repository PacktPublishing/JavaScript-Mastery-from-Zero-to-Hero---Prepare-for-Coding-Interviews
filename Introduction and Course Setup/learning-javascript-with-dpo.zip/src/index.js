// Course Notes:
document.getElementById("lesson").innerHTML = `

`;

// Code Examples:

// Exercise
document.getElementById("exercise").innerHTML = `

`;

// Exercise Solution:
