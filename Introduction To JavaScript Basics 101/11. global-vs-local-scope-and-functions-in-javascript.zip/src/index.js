// Course Notes:
document.getElementById("lesson").innerHTML = `

Scope in JavaScript refers to the current context of code, 
which determines the accessibility of variables to JavaScript. 
The two types of scope are local and global: 

Global variables are those declared outside of a block. 
Local variables are those declared inside of a block.

var variables automatically move to the global scope which 
can create unintended problems in you code

using let and const can be much more precise. this can 
be evidently seen with functions

`;

// Code Examples:

let x = 2;

function blockOfCode() {
  let x = 3;
  return x;
}

console.log(blockOfCode(), x);

// Exercise
document.getElementById("exercise").innerHTML = `

`;

// Exercise Solution:
