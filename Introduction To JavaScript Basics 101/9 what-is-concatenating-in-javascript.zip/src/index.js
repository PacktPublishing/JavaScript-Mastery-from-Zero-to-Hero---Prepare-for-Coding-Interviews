// Course Notes:
document.getElementById("lesson").innerHTML = `

Concatenating in JavaScript is when you add one string (or append) 
to another string

`;

// Code Examples:

const partOne = "what would you like";
const partTwo = " to be when you grow up";

console.log("example 1", partOne + partTwo);
console.log("example 2", partOne.concat(partTwo));

// Exercise
document.getElementById("exercise").innerHTML = `

1. Initialize a reassignable variable  
named newPhrase to the incomplete following sentence: 'once upon a time'

2. Using the Augmented Plus Operator modify the phrase variable so that
the sentence is completed with your own words by concatenating them to 
the phrase variable and log your results. 
`;

// Exercise Solution:

let newPhrase = "once upon a time";
console.log("Solution", (newPhrase += " a spaceship landed in my kitchen"));
