// Course Notes:
document.getElementById("lesson").innerHTML = `

Comments are used in JavaScript in order to explain what 
the code means making it much more readable 

There are two ways to write comments in JavaScript:
1. In-line comments
2. Multi-line comments

`;

// Code Examples:

// two forward slashes: // are in line comments

/* this 
is 
a 
multi-line 
comment */

// Exercise
document.getElementById("exercise").innerHTML = `
 1. Write a short in line comment about why you
 learning JavaScript 

 2. Write a lengthier multi line comment about
 your goals for learning and studying programming!

`;

// Exercise Solution:

// I am learning JavaScript because it's the best!

/* I am studying programming so that I can 
make an amazing RPG game one day and change
the world with decentralization and AI */
