// Course Notes:
document.getElementById("lesson").innerHTML = `
Accessing Arrays - Retreiving Data 

Arrays are not only meant for storing data, but for
retreiving data as well. 

Quite logically, when we declare an array with 5 elements
then there are going to be 5 elements in the array. 

For Ex: let newArray = [1,2,3,4,5]
newArray2 = [0,1,2,3,4,5]

in newArray the index value of the item 1 = 0, 
item 2 = 1, item 3 = 2, item 4 = 3 ...

Every item in an array in Javascript is marked with an index.
It is very important to note that in Javascript arrays start
at the zero index. That means the first array is actually 
starting at the 0 position and so on and so forth. 

Let's check out an example of how we could assign a value
from an array to a variable with Ex 1 below.

You can set the value to arrays by selecting the value
of the array and defining said value. EX 2 

`;

// Code Examples:
// Ex 1 (Assign Array value)
let animalArray = ["cat", "dog", "bird", "human"];
let myFavoriteAnimal = animalArray[3];
console.log("my favorite animal is a", myFavoriteAnimal);

// EX 2 (Set Array Value)
animalArray[1] = "rhino";
console.log("updated array values:", animalArray);

// Exercise
document.getElementById("exercise").innerHTML = `
1. Given the following array: let cityWeatherData = [true, "cold", "summer", "new york"];
it is most likely incorrect that it's cold in the summer time in new york.
Your mission is to change the true value to false.
2. Log out the new values of cityWeatherData
Good luck!
`;

// Exercise Solution:

let cityWeatherData = [true, "cold", "summer", "new york"];
cityWeatherData[0] = false;
console.log("updated cityWeatherData", cityWeatherData);
